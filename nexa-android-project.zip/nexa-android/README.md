# Nexa para Android (versão inicial)

Aplicativo Android nativo leve que abre a Nexa publicada em `https://nelsontavares8945-beep.github.io/nexa-assistente/` dentro de uma WebView. Preserva conversas no armazenamento local do WebView e permite câmera, microfone e seletor de arquivos pelos controles do site.

## O que esta versão faz
- Instala como aplicativo Android chamado Nexa e pode ser aberta pela tela inicial.
- Usa câmera/microfone mediante autorização do Android e permite escolher arquivos.
- Mantém conversas locais no dispositivo.

## O que ainda não faz
- Não implementa palavra de ativação própria "Nexa" em segundo plano e não se declara como assistente digital padrão. Dizer "Nexa" sozinha não abre o app nesta versão. Um assistente padrão com ativação por hotword exige serviços nativos Android, detecção de palavra, suporte do fabricante/aparelho e testes específicos.
- A abertura do app por “Hey Google, abrir Nexa” depende do Google Assistente reconhecer o nome do app instalado; não é ativação independente pela palavra “Nexa”.

## Build
Requer Android SDK 35 e JDK 17:

```sh
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.
